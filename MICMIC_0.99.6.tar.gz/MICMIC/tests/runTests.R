BiocGenerics:::testPackage("MICMIC")
